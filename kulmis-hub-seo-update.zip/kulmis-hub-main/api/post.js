const fs = require('fs');
const path = require('path');

const SUPABASE_URL = 'https://wxamihjterffxrnpqxwt.supabase.co';
const SUPABASE_KEY = 'sb_publishable_KXBcUODUGXrWUTY70jNPvw_2SwNy-A1';
const SITE_URL = 'https://kulmishub.com';
const DEFAULT_IMAGE = `${SITE_URL}/favicon.png`;

function createPostSlug(title) {
  return String(title || 'post')
    .toLowerCase().trim().normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
}

function esc(value) {
  return String(value == null ? '' : value).replace(/[&<>"']/g, ch => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[ch]);
}

// Keep basic article formatting while removing scripts, event handlers and unsafe URLs.
function safeDescription(input) {
  let html = String(input || '');
  html = html.replace(/<(script|style|iframe|object|embed|form)[\s\S]*?<\/\1\s*>/gi, '');
  html = html.replace(/<!--([\s\S]*?)-->/g, '');
  const allowed = new Set(['P','BR','STRONG','B','EM','I','U','UL','OL','LI','H2','H3','H4','BLOCKQUOTE','HR','A']);
  return html.replace(/<\/?([a-z0-9]+)(\s[^>]*)?>/gi, (tag, rawName, attrs) => {
    const name = rawName.toUpperCase();
    if (!allowed.has(name)) return '';
    if (/^<\//.test(tag)) return `</${name.toLowerCase()}>`;
    if (name === 'BR' || name === 'HR') return `<${name.toLowerCase()}>`;
    if (name !== 'A') return `<${name.toLowerCase()}>`;
    const hrefMatch = String(attrs || '').match(/\bhref\s*=\s*(["'])(.*?)\1/i);
    const href = hrefMatch ? hrefMatch[2].trim() : '';
    if (!/^https?:\/\//i.test(href)) return '<a>';
    return `<a href="${esc(href)}" target="_blank" rel="noopener noreferrer">`;
  });
}

function plainText(html) {
  return String(html || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
}

function setMeta(html, selector, attr, value) {
  const escaped = esc(value);
  const match = selector.match(/^meta\[(name|property)="([^"]+)"\]$/);
  if (!match) return html;
  const [, key, name] = match;
  const re = new RegExp(`<meta\\s+[^>]*${key}=["']${name}["'][^>]*>`, 'i');
  const tag = `<meta ${key}="${name}" ${attr}="${escaped}">`;
  return re.test(html) ? html.replace(re, tag) : html.replace('</head>', `  ${tag}\n</head>`);
}

function postMarkup(row, title) {
  const image = row.image_url ? `<img class="post-image" src="${esc(row.image_url)}" alt="${esc(title)}">` : '';
  const description = row.description ? `<div class="post-description">${safeDescription(row.description)}</div>` : '';
  const apply = row.link && /^https?:\/\//i.test(String(row.link))
    ? `<p><a class="post-action" href="${esc(row.link)}" target="_blank" rel="noopener noreferrer">Official / Apply</a></p>` : '';
  return `${image}<h1 class="post-title">${esc(title)}</h1>${row.country ? `<p><b>Wadanka:</b> ${esc(row.country)}</p>` : ''}${row.location ? `<p><b>Goobta:</b> ${esc(row.location)}</p>` : ''}${row.deadline ? `<p><b>Deadline:</b> ${esc(row.deadline)}</p>` : ''}${description}${apply}`;
}

module.exports = async function handler(req, res) {
  const slug = String((req.query && req.query.slug) || '').replace(/^\/+|\/+$/g, '');
  if (!slug || slug.length > 180) return res.status(400).send('Invalid post URL');

  try {
    const endpoint = `${SUPABASE_URL}/rest/v1/opportunities?select=*&published=eq.true&order=created_at.desc`;
    const response = await fetch(endpoint, {
      headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` }
    });
    if (!response.ok) throw new Error(`Supabase request failed: ${response.status}`);
    const rows = await response.json();
    const row = rows.find(item => createPostSlug(item.title || item.program || item.company || 'Fursad') === slug);

    if (!row) {
      res.setHeader('Cache-Control', 'public, s-maxage=60, stale-while-revalidate=300');
      return res.status(404).send('Post not found');
    }

    const title = row.title || row.program || row.company || 'Fursad';
    const seoTitle = String(row.seo_title || `${title} | KULMIS HUB`).trim();
    const description = String(row.meta_description || plainText(row.description) || 'Ka hel faahfaahinta fursaddan KULMIS HUB.').trim().slice(0, 300);
    const canonical = `${SITE_URL}/${encodeURIComponent(slug)}`;
    const image = row.image_url && /^https?:\/\//i.test(row.image_url) ? row.image_url : DEFAULT_IMAGE;

    const indexPath = path.join(__dirname, '..', 'index.html');
    let html = fs.readFileSync(indexPath, 'utf8');
    html = html.replace(/<title>[\s\S]*?<\/title>/i, `<title>${esc(seoTitle)}</title>`);
    html = setMeta(html, 'meta[name="description"]', 'content', description);
    html = setMeta(html, 'meta[property="og:site_name"]', 'content', 'KULMIS HUB');
    html = setMeta(html, 'meta[property="og:type"]', 'content', 'article');
    html = setMeta(html, 'meta[property="og:title"]', 'content', seoTitle);
    html = setMeta(html, 'meta[property="og:description"]', 'content', description);
    html = setMeta(html, 'meta[property="og:url"]', 'content', canonical);
    html = setMeta(html, 'meta[property="og:image"]', 'content', image);
    html = setMeta(html, 'meta[name="twitter:title"]', 'content', seoTitle);
    html = setMeta(html, 'meta[name="twitter:description"]', 'content', description);
    html = setMeta(html, 'meta[name="twitter:image"]', 'content', image);
    html = html.replace(/<link\s+rel=["']canonical["'][^>]*>/i, `<link rel="canonical" href="${esc(canonical)}">`);
    html = html.replace('<div id="postView" class="post-view">', '<div id="postView" class="post-view active">');
    html = html.replace('<div id="postContent"></div>', `<div id="postContent">${postMarkup(row, title)}</div>`);

    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('X-Robots-Tag', 'index, follow');
    res.setHeader('Cache-Control', 'public, s-maxage=300, stale-while-revalidate=1800');
    return res.status(200).send(html);
  } catch (error) {
    console.error('Post rendering failed:', error);
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    return res.status(500).send('Post temporarily unavailable');
  }
};
