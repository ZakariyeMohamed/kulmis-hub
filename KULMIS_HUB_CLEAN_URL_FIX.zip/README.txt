KULMIS HUB — Clean URL Fix

Files:
1. index.html — updated KULMIS HUB homepage with clean URL routing.
2. vercel.json — Vercel SPA rewrite so direct URLs do not return 404.

Replace the current root index.html with this index.html.
Upload vercel.json to the same root folder as index.html.
Then redeploy on Vercel.

Examples:
https://www.kulmishub.com/
https://www.kulmishub.com/deeqo-waxbarasho
https://www.kulmishub.com/seminars
https://www.kulmishub.com/fursadaha-shaqo
https://www.kulmishub.com/waa-maxay-sponsorship-jobs

Post links are generated from the post title, for example:
https://www.kulmishub.com/waa-maxay-sponsorship-jobs
